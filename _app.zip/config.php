<?php
$servidor = 'localhost';
$usuario = 'root';
$pass = 'root';
$bbdd = 'quiz';
?>
